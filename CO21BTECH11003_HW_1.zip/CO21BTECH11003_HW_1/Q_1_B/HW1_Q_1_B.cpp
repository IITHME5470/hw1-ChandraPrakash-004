#include <bits/stdc++.h>
#include <sys/stat.h>
using namespace std;

void printToFile(int n, double** A, int formatFlag) {
    stringstream ss;
    ss << "array ";

    char numStr[7];
    sprintf(numStr, "%06d", n); // Correct way to format with leading zeros
    ss << numStr;

    string filename = ss.str();

    if (formatFlag == 0) {
        filename += " asc.out";
        ofstream outfile(filename.c_str());
        if (!outfile.is_open()) { // Check if file opened successfully
            cerr << "Error opening output file: " << filename << endl;
            return;
        }
        outfile << fixed << setprecision(15);
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                outfile << A[i][j] << " ";
            }
            outfile << endl;
        }
        outfile.close(); // Close the file
    } else if (formatFlag == 1) {
        filename += " bin.out";
        FILE* outfile = fopen(filename.c_str(), "wb");
        if (!outfile) { // Check if file opened successfully
            cerr << "Error opening output file: " << filename << endl;
            return;
        }
        fwrite(A[0], sizeof(double), n * n, outfile); // Writing raw data of doubles
        fclose(outfile);
    } else {
        cerr << "Invalid format flag" << endl;
    }
}

int main() {
    ifstream infile("input.in");
    if (!infile.is_open()) {
        cerr << "Error opening input file: input.in" << endl;
        return 1;
    }

    int n;
    infile >> n;
    infile.close();

    double** A = new double*[n];
    for (int i = 0; i < n; i++) {
        A[i] = new double[n];
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            A[i][j] = i + j; // Sample data
        }
    }

    int formatFlag = 0;
    printToFile(n, A, formatFlag);

    formatFlag = 1;
    printToFile(n, A, formatFlag);

    // Memory estimation
    size_t memorySize = static_cast<size_t>(n) * n * sizeof(double);
    cout << "Estimated memory size of the array: " << memorySize << " bytes ("
             << static_cast<double>(memorySize) / (1024 * 1024) << " MB)" << endl;

    // File size estimation (using sys/stat.h)
    struct stat st;

    stringstream ssAscii;
    ssAscii << "array ";
    char numStrAscii[7];
    sprintf(numStrAscii, "%06d", n);
    ssAscii << numStrAscii << " asc.out";
    if (stat(ssAscii.str().c_str(), &st) == 0) {
        cout << "Size of ASCII file: " << st.st_size << " bytes ("
                 << static_cast<double>(st.st_size) / (1024 * 1024) << " MB)" << endl;
    } else {
        cerr << "Could not get ASCII file size." << endl;
    }
    stringstream ssBinary;
    ssBinary << "array ";
    char numStrBinary[7];
    sprintf(numStrBinary, "%06d", n);
    ssBinary << numStrBinary << " bin.out";
    if (stat(ssBinary.str().c_str(), &st) == 0) {
        cout << "Size of Binary file: " << st.st_size << " bytes ("
                 << static_cast<double>(st.st_size) / (1024 * 1024) << " MB)" << endl;
    } else {
        cerr << "Could not get Binary file size." << endl;
    }

    for (int i = 0; i < n; i++) {
        delete[] A[i];
    }
    delete[] A;

    return 0;
}
