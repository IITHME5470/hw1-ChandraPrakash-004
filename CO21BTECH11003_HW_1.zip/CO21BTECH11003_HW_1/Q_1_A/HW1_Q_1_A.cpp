#include <bits/stdc++.h>
using namespace std;

void printToFile(int n, int** A, int formatFlag) {
    std::stringstream ss;
    ss << "array ";

    char numStr[7];
    std::sprintf(numStr, "%06d", n); // Correct way to format with leading zeros
    ss << numStr;

    std::string filename = ss.str();

    if (formatFlag == 0) {
        filename += " asc.out";
        std::ofstream outfile(filename.c_str());
        if (!outfile.is_open()) { // Check if file opened successfully
          std::cerr << "Error opening output file: " << filename << std::endl;
          return;
        }
        outfile << std::fixed << std::setprecision(15);
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                outfile << A[i][j] << " ";
            }
            outfile << std::endl;
        }
        outfile.close(); // Close the file
    } else if (formatFlag == 1) {
        filename += " bin.out";
        FILE* outfile = std::fopen(filename.c_str(), "wb");
        if (!outfile) { // Check if file opened successfully
          std::cerr << "Error opening output file: " << filename << std::endl;
          return;
        }
        std::fwrite(A, sizeof(int), n * n, outfile);
        std::fclose(outfile);
    } else {
        std::cerr << "Invalid format flag" << std::endl;
    }
}

int main() {
    std::ifstream infile("input.in");
    if (!infile.is_open()) {
      std::cerr << "Error opening input file: input.in" << std::endl;
      return 1;
    }

    int n;
    infile >> n;
    infile.close();

    int** A = new int*[n];
    for (int i = 0; i < n; i++) {
        A[i] = new int[n];
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            A[i][j] = i + j;
        }
    }
    // 0 for Ascii and 1 for binary
    int formatFlag = 0;
    printToFile(n, A, formatFlag);

    for (int i = 0; i < n; i++) {
        delete[] A[i];
    }
    delete[] A;

    return 0;
}