#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <sstream>
#include <cstdlib>
#include <iomanip>
#include <string>
#include <limits>
using namespace std;

// Function to format a number with leading zeros
string formatWithZeros(int num, int digits) {
    stringstream ss;
    ss << setw(digits) << setfill('0') << num;
    return ss.str();
}

// Function to read an integer from a file
int readIntFromFile(const string& filename) {
    ifstream file(filename.c_str());
    if (!file.is_open()) {
        cerr << "Error opening file: " << filename << endl;
        exit(1);
    }

    int n;
    file >> n;
    file.close();
    return n;
}

// Function to read a matrix from a file AND PRINT IT
vector<vector<double> > readMatrixFromFile(const string& filename, int n) {
    ifstream file(filename.c_str());
    if (!file.is_open()) {
        cerr << "Error opening file: " << filename << endl;
        exit(1);
    }

    vector<vector<double> > matrix(n, vector<double>(n));
    //cout << "Matrix from " << filename << ":" << endl;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            string val;
            file >> val;
            istringstream iss(val);
            double value;
            if (!(iss >> value)) {
                cerr << "Error reading value from " << filename << endl;
                exit(1);
            }
            matrix[i][j] = value;

           // cout << matrix[i][j] << " ";      // To chaeck code read the values correctly
        }
        //cout << endl;
    }
    file.close();
    return matrix;
}

// Function to read a vector from a file
vector<double> readVectorFromFile(const string& filename, int n) {
    ifstream file(filename.c_str());
    if (!file.is_open()) {
        cerr << "Error opening file: " << filename << endl;
        exit(1);
    }

    vector<double> vec(n);
    //cout << "Vector from " << filename << ":" << endl;
    for (int i = 0; i < n; ++i) {
        string val;
        file >> val;
        istringstream iss(val);
        double value;
        if (!(iss >> value)) {
            cerr << "Error reading value from " << filename << endl;
            exit(1);
        }
        vec[i] = value;

       // cout << vec[i] << " ";   // To chaeck code read the values correctly
    }
    cout << endl;
    file.close();
    return vec;
}

// Function to check if a vector is an eigenvector of a matrix
bool isEigenvector(const vector<vector<double> >& matrix, const vector<double>& vec, double& eigenvalue) {
    int n = matrix.size();
    vector<double> product(n);
    for (int i = 0; i < n; ++i) {
        product[i] = 0;
        for (int j = 0; j < n; ++j) {
            product[i] += matrix[i][j] * vec[j];
        }
    }

    double tolerance = 1e-6;
    bool is_eigenvector = true;

    int first_nonzero = -1;
    for (int i = 0; i < n; ++i) {
        if (abs(vec[i]) > tolerance) {
            first_nonzero = i;
            break;
        }
    }

    if (first_nonzero == -1) {
        return false;
    }

    eigenvalue = product[first_nonzero] / vec[first_nonzero];

    for (int i = 0; i < n; ++i) {
        if ((product[i] - (vec[i] * eigenvalue)) > tolerance) {
            is_eigenvector = false;
            break;
        }
    }

    return is_eigenvector;
}

// Function to write the eigenvalue to a .out file
void writeEigenvalueToOutFile(const string& vec_filename, double eigenvalue) {
    string out_filename = vec_filename;
    size_t last_dot = out_filename.find_last_of('.');
    if (last_dot != string::npos) {
        out_filename = out_filename.substr(0, last_dot) + ".out";
    } else {
        out_filename += ".out"; // Add .out if no extension
    }

    ofstream outfile(out_filename.c_str()); // Open in write mode (creates or overwrites)
    if (!outfile.is_open()) {
        cerr << "Error creating/opening output file: " << out_filename << endl;
        exit(1);
    }
    outfile << fixed << setprecision(numeric_limits<double>::digits10 + 1) << eigenvalue << endl;
    outfile.close();
}

int main() {
    // Read n from input.in
    int n = readIntFromFile("input.in");

    
    string matrix_filename = "mat_" + formatWithZeros(n, 6) + ".in";
    vector<vector<double> > matrix = readMatrixFromFile(matrix_filename, n);    // Read matrix from mat_00000{n}.in

    // Process each vector file
    for (int vecnum = 1; ; ++vecnum) {
        string vec_filename = "vec_" + formatWithZeros(n, 6) + "_" + formatWithZeros(vecnum, 6) + ".in";
        ifstream test_file(vec_filename.c_str());
        if (!test_file.is_open()) {
            break;
        }
        test_file.close(); 
        vector<double> vec = readVectorFromFile(vec_filename, n); // Vector file

        // Check if it's an eigenvector
        double eigenvalue;
        if (isEigenvector(matrix, vec, eigenvalue)) {
            cout << vec_filename << " : Yes : " << eigenvalue << endl;
            writeEigenvalueToOutFile(vec_filename, eigenvalue);
        } else {
            cout << vec_filename << " : Not an eigenvector" << endl;
        }
    }

    return 0;
}